"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const auth_1 = require("./routes/auth");
const datasets_1 = require("./routes/datasets");
const metrics_1 = require("./routes/metrics");
const notes_1 = require("./routes/notes");
const payments_1 = require("./routes/payments");
const profile_1 = require("./routes/profile");
const upload_history_1 = require("./routes/upload-history");
const user_1 = require("./routes/user");
const admin_1 = require("./routes/admin");
const cloudinary_1 = require("./routes/cloudinary");
const chat_proxy_1 = require("./routes/chat-proxy");
const preprocessing_1 = require("./routes/preprocessing");
const corsHeaders = {
    'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGINS || 'http://localhost:3000,https:datavizai.editwithsanjay.in',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Max-Age': '86400'
};
const routes = {
    '/auth': auth_1.authRoutes,
    '/datasets': datasets_1.datasetsRoutes,
    '/metrics': metrics_1.metricsRoutes,
    '/notes': notes_1.notesRoutes,
    '/payments': payments_1.paymentsRoutes,
    '/profile': profile_1.profileRoutes,
    '/upload-history': upload_history_1.uploadHistoryRoutes,
    '/user': user_1.userRoutes,
    '/admin': admin_1.adminRoutes,
    '/cloudinary': cloudinary_1.cloudinaryRoutes,
    '/chat-proxy': chat_proxy_1.chatProxyRoutes,
    '/preprocessing': preprocessing_1.preprocessingRoutes
};
const handler = async (event, context) => {
    try {
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: corsHeaders,
                body: ''
            };
        }
        const path = event.path || '';
        const method = event.httpMethod;
        console.log(`Request: ${method} ${path}`);
        let routeHandler = null;
        let routePath = '';
        for (const [route, handler] of Object.entries(routes)) {
            if (path.startsWith(route)) {
                routeHandler = handler;
                routePath = route;
                break;
            }
        }
        if (!routeHandler) {
            return {
                statusCode: 404,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Route not found' })
            };
        }
        const result = await routeHandler(event, context, routePath);
        const responseHeaders = {
            ...corsHeaders,
            ...result.headers
        };
        const body = typeof result.body === 'string' ? result.body : JSON.stringify(result.body);
        return {
            statusCode: result.statusCode,
            headers: responseHeaders,
            body
        };
    }
    catch (error) {
        console.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : 'Unknown error'
            })
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map