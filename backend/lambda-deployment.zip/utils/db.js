"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectToDatabase = connectToDatabase;
exports.getDb = getDb;
exports.getClient = getClient;
exports.closeConnection = closeConnection;
const mongodb_1 = require("mongodb");
let client = null;
let db = null;
async function connectToDatabase() {
    if (client && db) {
        return { client, db };
    }
    const uri = process.env.MONGODB_URI;
    const dbName = process.env.DB_NAME;
    if (!uri) {
        throw new Error('MONGODB_URI environment variable is not set');
    }
    if (!dbName) {
        throw new Error('DB_NAME environment variable is not set');
    }
    try {
        client = new mongodb_1.MongoClient(uri);
        await client.connect();
        db = client.db(dbName);
        console.log('Connected to MongoDB successfully');
        return { client, db };
    }
    catch (error) {
        console.error('Failed to connect to MongoDB:', error);
        throw error;
    }
}
async function getDb() {
    const { db } = await connectToDatabase();
    return db;
}
async function getClient() {
    const { client } = await connectToDatabase();
    return client;
}
async function closeConnection() {
    if (client) {
        await client.close();
        client = null;
        db = null;
    }
}
//# sourceMappingURL=db.js.map