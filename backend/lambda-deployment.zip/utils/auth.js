"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyToken = verifyToken;
exports.generateToken = generateToken;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const mongodb_1 = require("mongodb");
const db_1 = require("./db");
async function verifyToken(event) {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader) {
            return null;
        }
        if (authHeader.startsWith('Bearer ')) {
            const tokenOrId = authHeader.substring(7);
            if (/^[a-f\d]{24}$/i.test(tokenOrId)) {
                return { userId: tokenOrId, email: '' };
            }
            try {
                const decoded = jsonwebtoken_1.default.verify(tokenOrId, process.env.JWT_SECRET || 'fallback-secret');
                const db = await (0, db_1.getDb)();
                const user = await db.collection('users').findOne({ _id: new mongodb_1.ObjectId(decoded.userId) }, { projection: { password: 0 } });
                if (!user) {
                    return null;
                }
                return {
                    userId: decoded.userId,
                    email: decoded.email
                };
            }
            catch (e) {
                return null;
            }
        }
        return null;
    }
    catch (error) {
        console.error('Token verification error:', error);
        return null;
    }
}
function generateToken(userId, email) {
    return jsonwebtoken_1.default.sign({ userId, email }, process.env.JWT_SECRET || 'fallback-secret', { expiresIn: '7d' });
}
//# sourceMappingURL=auth.js.map