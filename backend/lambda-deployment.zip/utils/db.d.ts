import { MongoClient, Db } from 'mongodb';
export declare function connectToDatabase(): Promise<{
    client: MongoClient;
    db: Db;
}>;
export declare function getDb(): Promise<Db>;
export declare function getClient(): Promise<MongoClient>;
export declare function closeConnection(): Promise<void>;
//# sourceMappingURL=db.d.ts.map