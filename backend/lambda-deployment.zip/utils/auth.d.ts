import { APIGatewayProxyEvent } from 'aws-lambda';
export declare function verifyToken(event: APIGatewayProxyEvent): Promise<{
    userId: string;
    email: string;
} | null>;
export declare function generateToken(userId: string, email: string): string;
//# sourceMappingURL=auth.d.ts.map