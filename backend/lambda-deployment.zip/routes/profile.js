"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.profileRoutes = void 0;
const mongodb_1 = require("mongodb");
const db_1 = require("../utils/db");
const auth_1 = require("../utils/auth");
const profileRoutes = async (event, context, basePath) => {
    const path = event.path || '';
    const method = event.httpMethod;
    const relativePath = path.replace(basePath, '');
    try {
        const user = await (0, auth_1.verifyToken)(event);
        if (!user) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Unauthorized' })
            };
        }
        if (relativePath === '' && method === 'GET') {
            return await handleGetProfile(event, user.userId);
        }
        else if (relativePath === '' && method === 'PUT') {
            return await handleUpdateProfile(event, user.userId);
        }
        else {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Profile route not found' })
            };
        }
    }
    catch (error) {
        console.error('Profile route error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};
exports.profileRoutes = profileRoutes;
async function handleGetProfile(event, userId) {
    try {
        const db = await (0, db_1.getDb)();
        const user = await db.collection('users').findOne({ _id: new mongodb_1.ObjectId(userId) }, { projection: { password: 0 } });
        if (!user) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'User not found' })
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify({
                id: user._id.toString(),
                name: user.name,
                email: user.email,
                image: user.image,
                createdAt: user.createdAt,
                updatedAt: user.updatedAt
            })
        };
    }
    catch (error) {
        console.error('Error fetching profile:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to fetch profile' })
        };
    }
}
async function handleUpdateProfile(event, userId) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { name, image } = body;
        if (!name?.trim()) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Name is required' })
            };
        }
        const db = await (0, db_1.getDb)();
        const result = await db.collection('users').updateOne({ _id: new mongodb_1.ObjectId(userId) }, {
            $set: {
                name: name.trim(),
                image: image?.trim() || undefined,
                updatedAt: new Date()
            }
        });
        if (result.matchedCount === 0) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'User not found' })
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Profile updated successfully' })
        };
    }
    catch (error) {
        console.error('Error updating profile:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to update profile' })
        };
    }
}
//# sourceMappingURL=profile.js.map