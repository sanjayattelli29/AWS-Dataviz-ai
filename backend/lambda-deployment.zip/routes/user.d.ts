import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare const userRoutes: (event: APIGatewayProxyEvent, context: Context, basePath: string) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=user.d.ts.map