"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRoutes = void 0;
const mongodb_1 = require("mongodb");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const db_1 = require("../utils/db");
const authRoutes = async (event, context, basePath) => {
    const path = event.path || '';
    const method = event.httpMethod;
    const relativePath = path.replace(basePath, '');
    try {
        if (relativePath === '/register' && method === 'POST') {
            return await handleRegister(event);
        }
        else if (relativePath === '/login' && method === 'POST') {
            return await handleLogin(event);
        }
        else if (relativePath === '/session' && method === 'GET') {
            return await handleGetSession(event);
        }
        else if (relativePath === '/logout' && method === 'POST') {
            return await handleLogout(event);
        }
        else {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Auth route not found' })
            };
        }
    }
    catch (error) {
        console.error('Auth route error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};
exports.authRoutes = authRoutes;
async function handleRegister(event) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { name, email, password } = body;
        if (!name || !email || !password) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Name, email, and password are required' })
            };
        }
        const db = await (0, db_1.getDb)();
        const existingUser = await db.collection('users').findOne({ email });
        if (existingUser) {
            return {
                statusCode: 409,
                body: JSON.stringify({ error: 'User already exists' })
            };
        }
        const hashedPassword = await bcryptjs_1.default.hash(password, 12);
        const user = {
            name,
            email,
            password: hashedPassword,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        const result = await db.collection('users').insertOne(user);
        const token = jsonwebtoken_1.default.sign({ userId: result.insertedId.toString(), email }, process.env.JWT_SECRET || 'fallback-secret', { expiresIn: '7d' });
        return {
            statusCode: 201,
            body: JSON.stringify({
                message: 'User registered successfully',
                user: {
                    id: result.insertedId.toString(),
                    name,
                    email
                },
                token
            })
        };
    }
    catch (error) {
        console.error('Register error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to register user' })
        };
    }
}
async function handleLogin(event) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, password } = body;
        if (!email || !password) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Email and password are required' })
            };
        }
        const db = await (0, db_1.getDb)();
        const user = await db.collection('users').findOne({ email });
        if (!user) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Invalid credentials' })
            };
        }
        const isValidPassword = await bcryptjs_1.default.compare(password, user.password);
        if (!isValidPassword) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Invalid credentials' })
            };
        }
        const token = jsonwebtoken_1.default.sign({ userId: user._id.toString(), email }, process.env.JWT_SECRET || 'fallback-secret', { expiresIn: '7d' });
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Login successful',
                user: {
                    id: user._id.toString(),
                    name: user.name,
                    email: user.email
                },
                token
            })
        };
    }
    catch (error) {
        console.error('Login error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to login' })
        };
    }
}
async function handleGetSession(event) {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'No token provided' })
            };
        }
        const token = authHeader.substring(7);
        try {
            const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET || 'fallback-secret');
            const db = await (0, db_1.getDb)();
            const user = await db.collection('users').findOne({ _id: new mongodb_1.ObjectId(decoded.userId) }, { projection: { password: 0 } });
            if (!user) {
                return {
                    statusCode: 401,
                    body: JSON.stringify({ error: 'User not found' })
                };
            }
            return {
                statusCode: 200,
                body: JSON.stringify({
                    user: {
                        id: user._id.toString(),
                        name: user.name,
                        email: user.email
                    }
                })
            };
        }
        catch (jwtError) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Invalid token' })
            };
        }
    }
    catch (error) {
        console.error('Get session error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to get session' })
        };
    }
}
async function handleLogout(event) {
    return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Logged out successfully' })
    };
}
//# sourceMappingURL=auth.js.map