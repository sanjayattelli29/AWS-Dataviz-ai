import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare const datasetsRoutes: (event: APIGatewayProxyEvent, context: Context, basePath: string) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=datasets.d.ts.map