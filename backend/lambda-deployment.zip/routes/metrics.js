"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.metricsRoutes = void 0;
const mongodb_1 = require("mongodb");
const db_1 = require("../utils/db");
const auth_1 = require("../utils/auth");
const metricsRoutes = async (event, context, basePath) => {
    const path = event.path || '';
    const method = event.httpMethod;
    const relativePath = path.replace(basePath, '');
    try {
        const user = await (0, auth_1.verifyToken)(event);
        if (!user) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Unauthorized' })
            };
        }
        if (relativePath === '/save' && method === 'POST') {
            return await handleSaveMetrics(event, user.userId);
        }
        else if (relativePath === '/get' && method === 'GET') {
            return await handleGetMetrics(event, user.userId);
        }
        else if (relativePath === '/history' && method === 'GET') {
            return await handleGetMetricsHistory(event, user.userId);
        }
        else if (relativePath === '/list-datasets' && method === 'GET') {
            return await handleListDatasets(event, user.userId);
        }
        else {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Metrics route not found' })
            };
        }
    }
    catch (error) {
        console.error('Metrics route error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};
exports.metricsRoutes = metricsRoutes;
async function handleSaveMetrics(event, userId) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { datasetId, metrics, timestamp } = body;
        if (!datasetId || !metrics) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing required fields' })
            };
        }
        const db = await (0, db_1.getDb)();
        const result = await db.collection('user_metrics_cache').updateOne({ userId, datasetId }, {
            $set: {
                userId,
                datasetId,
                metrics,
                timestamp: timestamp || new Date().toISOString(),
                updatedAt: new Date(),
            }
        }, { upsert: true });
        return {
            statusCode: 200,
            body: JSON.stringify({
                success: true,
                message: 'Metrics saved successfully',
                metricId: result.upsertedId?.toString()
            })
        };
    }
    catch (error) {
        console.error('Error saving metrics:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to save metrics' })
        };
    }
}
async function handleGetMetrics(event, userId) {
    try {
        const datasetId = event.queryStringParameters?.datasetId;
        if (!datasetId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Dataset ID is required' })
            };
        }
        const db = await (0, db_1.getDb)();
        const metrics = await db.collection('user_metrics_cache').findOne({
            userId,
            datasetId
        });
        if (!metrics) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Metrics not found' })
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify(metrics)
        };
    }
    catch (error) {
        console.error('Error getting metrics:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to get metrics' })
        };
    }
}
async function handleGetMetricsHistory(event, userId) {
    try {
        const db = await (0, db_1.getDb)();
        const history = await db.collection('user_metrics_cache')
            .find({ userId })
            .sort({ updatedAt: -1 })
            .toArray();
        return {
            statusCode: 200,
            body: JSON.stringify(history)
        };
    }
    catch (error) {
        console.error('Error getting metrics history:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to get metrics history' })
        };
    }
}
async function handleListDatasets(event, userId) {
    try {
        const db = await (0, db_1.getDb)();
        const datasets = await db.collection('datasets')
            .find({ userId: new mongodb_1.ObjectId(userId) })
            .project({ _id: 1, name: 1, createdAt: 1 })
            .sort({ createdAt: -1 })
            .toArray();
        return {
            statusCode: 200,
            body: JSON.stringify(datasets.map(dataset => ({
                id: dataset._id.toString(),
                name: dataset.name,
                createdAt: dataset.createdAt
            })))
        };
    }
    catch (error) {
        console.error('Error listing datasets:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to list datasets' })
        };
    }
}
//# sourceMappingURL=metrics.js.map