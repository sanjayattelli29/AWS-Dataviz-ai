"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentsRoutes = void 0;
const razorpay_1 = __importDefault(require("razorpay"));
const db_1 = require("../utils/db");
const auth_1 = require("../utils/auth");
const razorpay = new razorpay_1.default({
    key_id: process.env.RAZORPAY_KEY_ID || '',
    key_secret: process.env.RAZORPAY_KEY_SECRET || ''
});
const paymentsRoutes = async (event, context, basePath) => {
    const path = event.path || '';
    const method = event.httpMethod;
    const relativePath = path.replace(basePath, '');
    try {
        const user = await (0, auth_1.verifyToken)(event);
        if (!user) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Unauthorized' })
            };
        }
        if (relativePath === '/create-order' && method === 'POST') {
            return await handleCreateOrder(event, user.userId);
        }
        else if (relativePath === '/confirm-payment' && method === 'POST') {
            return await handleConfirmPayment(event, user.userId);
        }
        else {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Payment route not found' })
            };
        }
    }
    catch (error) {
        console.error('Payment route error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};
exports.paymentsRoutes = paymentsRoutes;
async function handleCreateOrder(event, userId) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { amount, currency = 'INR', receipt } = body;
        if (!amount || !receipt) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Amount and receipt are required' })
            };
        }
        const options = {
            amount: amount * 100,
            currency,
            receipt,
            notes: {
                userId
            }
        };
        const order = await razorpay.orders.create(options);
        return {
            statusCode: 200,
            body: JSON.stringify({
                orderId: order.id,
                amount: order.amount,
                currency: order.currency,
                receipt: order.receipt
            })
        };
    }
    catch (error) {
        console.error('Error creating order:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to create order' })
        };
    }
}
async function handleConfirmPayment(event, userId) {
    try {
        const body = JSON.parse(event.body || '{}');
        const { paymentId, orderId, signature } = body;
        if (!paymentId || !orderId || !signature) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Payment ID, Order ID, and signature are required' })
            };
        }
        const text = orderId + '|' + paymentId;
        const crypto = require('crypto');
        const expectedSignature = crypto
            .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || '')
            .update(text)
            .digest('hex');
        if (expectedSignature !== signature) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Invalid payment signature' })
            };
        }
        const db = await (0, db_1.getDb)();
        const payment = {
            userId,
            paymentId,
            orderId,
            amount: body.amount,
            currency: body.currency,
            status: 'completed',
            createdAt: new Date()
        };
        await db.collection('payments').insertOne(payment);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Payment confirmed successfully',
                paymentId,
                orderId
            })
        };
    }
    catch (error) {
        console.error('Error confirming payment:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to confirm payment' })
        };
    }
}
//# sourceMappingURL=payments.js.map