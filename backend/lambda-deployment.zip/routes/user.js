"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userRoutes = void 0;
const mongodb_1 = require("mongodb");
const db_1 = require("../utils/db");
const auth_1 = require("../utils/auth");
const userRoutes = async (event, context, basePath) => {
    const path = event.path || '';
    const method = event.httpMethod;
    const relativePath = path.replace(basePath, '');
    try {
        const user = await (0, auth_1.verifyToken)(event);
        if (!user) {
            return { statusCode: 401, body: JSON.stringify({ error: 'Unauthorized' }) };
        }
        if (relativePath === '/upload-limits' && method === 'GET') {
            return await handleGetUploadLimits(user.userId);
        }
        else if (relativePath === '' && method === 'GET') {
            return await handleGetUserInfo(user.userId);
        }
        else {
            return { statusCode: 404, body: JSON.stringify({ error: 'User route not found' }) };
        }
    }
    catch (error) {
        console.error('User route error:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Internal server error' }) };
    }
};
exports.userRoutes = userRoutes;
async function handleGetUploadLimits(userId) {
    try {
        return {
            statusCode: 200,
            body: JSON.stringify({
                maxUploads: 10,
                maxFileSizeMB: 50
            })
        };
    }
    catch (error) {
        console.error('Error fetching upload limits:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to fetch upload limits' }) };
    }
}
async function handleGetUserInfo(userId) {
    try {
        const db = await (0, db_1.getDb)();
        const user = await db.collection('users').findOne({ _id: new mongodb_1.ObjectId(userId) });
        if (!user) {
            return { statusCode: 404, body: JSON.stringify({ error: 'User not found' }) };
        }
        return {
            statusCode: 200,
            body: JSON.stringify({
                id: user._id.toString(),
                name: user.name,
                email: user.email
            })
        };
    }
    catch (error) {
        console.error('Error fetching user info:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to fetch user info' }) };
    }
}
//# sourceMappingURL=user.js.map