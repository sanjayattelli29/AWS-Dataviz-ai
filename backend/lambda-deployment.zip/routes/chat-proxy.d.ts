import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare const chatProxyRoutes: (event: APIGatewayProxyEvent, context: Context, basePath: string) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=chat-proxy.d.ts.map