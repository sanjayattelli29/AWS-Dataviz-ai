import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare const metricsRoutes: (event: APIGatewayProxyEvent, context: Context, basePath: string) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=metrics.d.ts.map