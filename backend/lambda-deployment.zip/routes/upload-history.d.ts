import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare const uploadHistoryRoutes: (event: APIGatewayProxyEvent, context: Context, basePath: string) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=upload-history.d.ts.map